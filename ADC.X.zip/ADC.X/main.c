/*
 * File:   main.c
 * Author: Administrator
 *
 * Created on 29 December, 2020, 7:19 PM
 */


#include "config.h" // Send PIC 16f1517 configuration
#include "lcd.h"  //call LCD Functions
#include "I2C.h"  // Call I2C Functions
#include"RTC.h"  // Call RTC functions
char Tempr[] = " 00.0 C"; //set Temp display format in kelvin
int C;    
void ADC_Init()
{
TRISA = 0xff; //*set as input port*/ 
ADCON1 = 0b11110000; //Right Justify, FRC Clock , All pins as Analog Input and setting Reference Voltages 
ADCON0 = 0b00000001; //Turn ON ADC and Clock Selection
ADRESH = 0; //*Flush ADC output Register*/
ADRESL = 0;
}
unsigned int ADC_Read(unsigned char channel)
{

 ADCON0 |= channel<< 1; //Setting the required Bits
  __delay_ms(2); //Acquisition time to charge hold capacitor
  GO_nDONE = 1; //Initializes A/D Conversion
  while(GO_nDONE); //Wait for A/D Conversion to complete
  return ((ADRESH<< 8)+ADRESL); //Returns Result
}
void main() {               
    Init_LCD(); // start LCD function
    InitI2C();  // Initialize I2C bus function
    ADC_Init(); //* initialize 10-bit ADC*/  
    while(1)
   {
    Lcd_Clear();
    Lcd_Set_Cursor(0x80);
    Lcd_Write_String("  Welcome  ");
    Lcd_Set_Cursor(0xC0);
    Lcd_Write_String(" Microdigisoft ");
    __delay_ms(50);           //   50ms Delay.
    Lcd_Clear();
    Lcd_Set_Cursor(0x80);
    DisplayDateOnLCD(Get_DS1307_RTC_Date());   
    Lcd_Set_Cursor(0);
    C = ADC_Read(0) * 0.489;               // // Read analog voltage and convert it to degree Celsius (0.489 = 500/1023)
    if (C > 99)
      Tempr[0]  = 1 + 48;              // Put 1 (of hundred)
    else
    Tempr[0]  = ' ';                 // Put space
    Tempr[1]  = (C / 10) % 10  + 48;
    Tempr[2]  =  C % 10  + 48;
    Tempr[5] = 223;                    // Put degree symbol ( � )
    Lcd_Set_Cursor(0xC0);
    Lcd_Write_String("Temp:");
    Lcd_Write_String(Tempr);
    __delay_ms(200);    //100 ms delay   
     }               
}
